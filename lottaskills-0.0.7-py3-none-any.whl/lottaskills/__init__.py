print(
    "\033[44m\033[97mThis is __init__.py, currently a hint.\033[0m\n"
    "\033[43m\033[30m - from lottaskills import loser\033[0m\n"
    "\033[43m\033[30m - from lottaskills import skillissue\033[0m\n"
    "\033[42m\033[30mto import the troll modules.\033[0m\n"
    "\033[43m\033[31mDo not use the library to do \033[7m`abusing`\033[31m/\033[7m`harmful`\033[31m activities\033[0m"
)
